#调整窗口大小
import os
os.system('mode con cols=45 lines=18')

#导入所需模块
import time,win32gui,difflib,requests,sys
from wxauto import *

#赛博检测一下是不是用GUI拽起来的，如果不是，直接罢工
checkway='C:\ProgramData\EnglishHelper'
checkfile='Cookies.txt'
checkfile2='Results.txt'
checkpath=os.path.join(checkway,checkfile)
checkpath2=os.path.join(checkway,checkfile2)
if os.path.exists(checkway)==False or os.path.exists(checkpath)==False or os.path.exists(checkpath2)==False:
    print('-------------------------------')
    print()
    print('是不是忘记了用图形界面拉起？')
    print('如果使用了图形界面，请检查版本是否对应')
    print('请使用正确的GUI拉起我哦')
    print('否则会出问题')
    print()
    print('-------------------------------')
    time.sleep(8)
    sys.exit(0)
else:
    pass





#导入库+赛博自查
#====================================================================
#====================================================================
#====================================================================
#====================================================================
#====================================================================
#定义函数





#定义相似算法函数
def SimilarMatching(A,transback):
    a=difflib.SequenceMatcher(None,A,transback).ratio()
    return a

#定义报头函数
def Headers():
    #定义路径、文件名和path
    fway=r"C:\ProgramData\EnglishHelper"
    finame='Cookies.txt'
    fpath=os.path.join(fway,finame)

    #使用只读权限打开Cookies.txt，设置content变量并作为报头一部分
    with open(fpath,'r') as file:
        content=file.read()
    headers={
    "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0",
    "Cookie": content 
    }
    return(headers)

#获取切片后的单词，以备发送
def GetWords():
    #设置起始位置
    start_index = lstmsg[1].find("【单选】") + len("【单选】")
    end_index = lstmsg[1].find("[")

    #获取字符串格式的单词本体并返回值
    gotword = lstmsg[1][start_index:end_index].strip()
    return gotword

#将获取到的单词发送至翻译提供商，并取得翻译结果
def GetAndSend(gottenword,Headers):
    print()
    print('请求翻译...')
    print()
    try:
        response=requests.post(trans,headers=Headers,data={'kw':gottenword})
        response.raise_for_status()
        data=response.json().get('data')
        return data[0]['v'] if data else None
    except Exception as e:
        print(f"抽风信息：{e}")
        return None

#定义每次回答后，清空单词存储区函数
def CleanAnsweredWord():
    A.clear()
    B.clear()
    C.clear()
    D.clear()

#写入log
def write_text_to_file(text, file_path):
    with open(fpath, "a", encoding="utf-8") as file:
        file.write(text)
        file.close()









#定义函数区
#======================================================================================================================
#======================================================================================================================
#======================================================================================================================
#======================================================================================================================
#======================================================================================================================
#设置变量区







#设置验证码数量变量
verify=0

#设置错误单词变量
erroranswer=0

#设置超时单词变量
timeouted=0

#设置错误情况变量
errorsit=0

#设置已背单词变量
answered=0

#老子网没卡
netcardon=0

#设置翻译API提供商
trans='https://fanyi.baidu.com/sug'

#设置单词存储区
A=[]
B=[]
C=[]
D=[]








#======================================================================================================================
#======================================================================================================================
#======================================================================================================================
#======================================================================================================================
#======================================================================================================================








while True:
    #检测微信窗口是否存在
    handle=win32gui.FindWindow(None,'微信')
    if handle==0:
        print('\033c')
        print('微信都不打开，背个啥啊')
        print('快去打开微信再来找我')
        time.sleep(2)
        print('\033c')
        sys.exit(0)

    #设置目标数量变量
    gradeanswer=input('请输入要背单词的数量:')

    #赛博bug半修复
    if gradeanswer=='':
        print('不打单词数量怎么背单词啊')
        time.sleep(1)
        print('\033c')
        continue
    elif '0' in gradeanswer or '1' in gradeanswer or '2' in gradeanswer or '3' in gradeanswer or '4' in gradeanswer or '5' in gradeanswer or '6' in gradeanswer or '7' in gradeanswer or '8' in gradeanswer or '9' in gradeanswer:
        if '.' in gradeanswer:
            print('单词数量怎么可能是小数')
            time.sleep(1)
            print('\033c')
            continue
        else:
            gradeanswer=int(gradeanswer)
    else:
        print('别瞎输，好好输')
        time.sleep(1)
        print('\033c')
        continue

    #打开(定义)微信
    wx=WeChat()

    #打印提示信息
    print('-------------------------------')
    print()
    print('程序正在寻找英语AI学习助手\n如果列表过长或电脑性能过低，可能会耗时较久\n程序没有卡死，无需进行其他操作')
    print()
    print('-------------------------------')

    #跟我亲爱的英语AI学习助手唠唠嗑
    wx.ChatWith('英语AI学习助手')
    wx.SendMsg('背单词')














        
    #如果已回答+错误情况<目标值
    while answered+errorsit+timeouted < gradeanswer:
        #延迟1.8秒执行
        time.sleep(1.8)

        #获取最后一条信息并储存
        lstmsg=wx.GetAllMessage()[-1]

        #如果检测到“请在20秒内回复答案”，则为A、B、C、D分别设置切片起始变量
        if "【单选】" in lstmsg[1]:
            #老子网没卡
            netcardon=0

            #浅浅切个片
            a_start=lstmsg[1].find("A. ")+len("A. ")
            a_end=lstmsg[1].find("B. ")
            b_start=lstmsg[1].find("B. ")+len("B. ")
            b_end=lstmsg[1].find("C. ")
            c_start=lstmsg[1].find("C. ")+len("C. ")
            c_end=lstmsg[1].find("D. ")
            d_start=lstmsg[1].find("D. ")+len("D. ")
            d_end=lstmsg[1].find("====================")

            #获取题目单词并调用发送函数
            wd=GetWords()
            hd=Headers()
            transback=GetAndSend(wd,hd)

            #一个简单的异常处理
            if type(transback) != type('test') or type(transback)==type(None):
                print('-------------------------------')
                print()
                print('出现错误，很有可能是Cookie值错误')
                print('如果之前能背，那就是sb百度翻译又抽风辣')
                print('李彦宏！！！！')
                print('遇事不决就选C')
                print()
                print('-------------------------------')
                errorsit+=1
                wx.SendMsg('C')
                continue
                
            #打印当前已背数量
            print('-------------------------------')
            print()
            print('当前正在背第 ',answered+errorsit+timeouted+1,' 个单词')

            #延迟0.4秒执行
            time.sleep(0.4)

            #检测错误数
            if "答题错误。正确答案" in lstmsg[1]:
                erroranswer+=1
                print('累计错误数：',erroranswer)
                time.sleep(0.6)
            
            #检测超时数
            if "答题超时" in lstmsg[1]:
                timeouted+=1
                print('累计超时数：',timeouted)
                time.sleep(0.6)

            #在单词存储区存储“对应选项”的“对应汉字”
            opa=lstmsg[1][a_start:a_end].strip()
            A.append(opa)
            opb=lstmsg[1][b_start:b_end].strip()
            B.append(opb)
            opc=lstmsg[1][c_start:c_end].strip()
            C.append(opc)
            opd=lstmsg[1][d_start:d_end].strip()
            D.append(opd)

            #将选项分别转换为字符串
            strA="".join(A)
            strB="".join(B)
            strC="".join(C)
            strD="".join(D)

            #调用相似算法
            sima=SimilarMatching(strA,transback)
            simb=SimilarMatching(strB,transback)
            simc=SimilarMatching(strC,transback)
            simd=SimilarMatching(strD,transback)

            #微信内发送选项
            if sima>simb and sima>simc and sima>simd:
                print('算法匹配答案为：A，发送')
                print()
                print('-------------------------------')
                wx.SendMsg("A")
            elif simb>sima and simb>simc and simb>simd:
                print('算法匹配答案为：B，发送')
                print()
                print('-------------------------------')
                wx.SendMsg("B")
            elif simc>sima and simc>simb and simc>simd:
                print('算法匹配答案为：C，发送')
                print()
                print('-------------------------------')
                wx.SendMsg("C")
            else:
                print('算法匹配答案为：D，发送')
                print()
                print('-------------------------------')
                wx.SendMsg("D")

        #如果上述条件不成立，则执行检测“验证单词学习行为”的操作，切片验证码并发送
        elif "验证单词学习行为" in lstmsg[1]:
            #老子网没卡
            netcardon=0

            #设置起始位置
            start_index = lstmsg[1].find("请回复") + len("请回复")
            end_index=lstmsg[1].find("验证单词学习行为")

            #设置变量veristr为发送字符串格式的切片(验证码)
            veristr=lstmsg[1][start_index:end_index].strip()
            print()
            print('该死的验证码：',veristr)
            print('又尼玛不算正确词')
            print("输他丫的")
            print()
            print('-------------------------------')
            wx.SendMsg(veristr)

            #喜提验证码+1
            verify+=1

        #否则，发送“背单词”
        else:
            wx.SendMsg("背单词")

            #网卡了，记录一下
            netcardon+=1

            #判断是否需要显示提示
            if netcardon>=2:
                print('-------------------------------')
                print()
                print('如果出现反复发送背单词的情况，建议检查网络')
                print('如果网络过于卡顿，会导致程序无法及时获取单词')
                print('从而一直尝试发送背单词')
                print()
                print('-------------------------------')

                #该死的帮手，又改模式了，现在只要重复发送背单词就会出10个新单词，我说循环怎么修不好，你妈的
                #先直接归零吧，之前背了多少我也不管了，多的就当送你了，期待这行代码能早早删除
                #哪个SB改的这个制度啊，md，直接导致爷的循环次数没法统计，艹
                answered=0 
            
        #调用清空函数
        CleanAnsweredWord()

        #判断已答题数量什么时候应该+1
        if "【单选】" in lstmsg[1]:
            answered+=1

    #背完单词后，跳出循环
    if answered+errorsit+timeouted == gradeanswer:
        print('\033c')
        print('需要查询当日正确数吗？(自动发送T)')
        checkorno=int(input('1：发送 | 0：退出 ：'))
        if checkorno==1:
            wx.ChatWith('英语AI学习助手')
            wx.SendMsg('T')
            break
        break
    break

#写入空值覆盖原结果
fway="C:\ProgramData\EnglishHelper"
finame='Results.txt'
fpath=os.path.join(fway,finame)
with open(fpath, "w", encoding="utf-8") as file:
    file.write('')
    file.close()

text_to_save1 = '已背单词数量：'+str(gradeanswer)
text_to_save2 = '\n错误数：'+str(erroranswer)
text_to_save3 = '\n验证码数：'+str(verify)
text_to_save4 = '\n超时数量：'+str(timeouted)
text_to_save5 = '\n错误情况：'+str(errorsit)
text_to_save6 = '\n统计数据仅供参考，且只统计当前程序运行周期数据'
text_to_save7 = '\n可能会有误差'

write_text_to_file(text_to_save1, fpath)
write_text_to_file(text_to_save2, fpath)
write_text_to_file(text_to_save3, fpath)
write_text_to_file(text_to_save4, fpath)
write_text_to_file(text_to_save5, fpath)
write_text_to_file(text_to_save6, fpath)
write_text_to_file(text_to_save7, fpath)