#导入图形界面库
import tkinter as tk
from tkinter import messagebox,Menu

#导入必备库
import os,threading
from threading import Thread





#导入库
#====================================================================
#====================================================================
#====================================================================
#====================================================================
#====================================================================
#定义函数





#如果我要关闭，怎么办？
def close():
    os.remove(delpath)
    os._exit(0)

#定义右键菜单包含功能
def cut():
    entry.event_generate("<<Cut>>")
def copy():
    entry.event_generate("<<Copy>>")
def paste():
    entry.event_generate("<<Paste>>")

#定义将输入框中的值写入到Cookie函数
def set_cookie():
    #检测是否创建文件夹
    if not os.path.exists(fway):
        os.makedirs(fway)
    else:
        pass
    
    #获取输入框中的值
    cookie = entry.get()

    #将Cookie值写入文件
    with open(fpath,'w') as file:
        file.write(cookie)    
        file.close()
        tk.messagebox.showinfo('恭喜','写入成功')
        #另一个赛博异常检测
        with open(fpath,'r') as file:
            content=file.read()
            if content=="":
                tk.messagebox.showerror('你大爷','Cookie值为空背鸡毛，老子不干了')
            else:
                root.destroy()






#定义函数
#====================================================================
#====================================================================
#====================================================================
#====================================================================
#====================================================================
#程序行为





#创建基础总结文件
delway=r"C:\ProgramData\EnglishHelper"
delname="Results.txt"
delpath=os.path.join(delway,delname)


#写入基础总结文件
if os.path.exists(delway)==False:
    os.makedirs(delway)
    with open(delpath,'w',encoding='utf-8') as file:
        file.write('日志为空')
        file.close
else:
    with open(delpath,'w',encoding='utf-8') as file:
        file.write('日志为空')
        file.close

#设置Cookie存储路径
fway=r"C:\ProgramData\EnglishHelper"
finame='Cookies.txt'
fpath=os.path.join(fway,finame)

# 创建Cookie输入窗口
root = tk.Tk()
root.title("请输入Cookie")
root.geometry("600x620+80+60")
root.resizable(width=False, height=False)
root.protocol("WM_DELETE_WINDOW",close)

#窗口上方文本参数设置
tk.Label(root, text="特别感谢：老柳、田哥；没有你们，就不会有本程序\n特别感谢：耿哥；没有你的issue，就不会有体验优化\n同时也是键盘提供者，没有他的键盘，我不会肝的这么快\n特别感谢：每一个陪我debug的人，没有你们，我就不会发现可能隐含在程序中的bug", font=("Microsoft YaHei", 10)).pack(pady=35)
tk.Label(root, text="------------------------------------------------------------", font=("Microsoft YaHei", 10)).pack(pady=0)
tk.Label(root, text="请到百度翻译网页获取Cookie，粘贴至下方输入框\n粘贴后点击设置Cookie\n出现”写入成功“即可进入主程序", font=("Microsoft YaHei", 10)).pack(pady=35)
tk.Label(root, text="------------------------------------------------------------", font=("Microsoft YaHei", 10)).pack(pady=0)
tk.Label(root, text="获取Token方法：打开浏览器并访问百度翻译官网，进入浏览器的开发者工具\n点击网络-Fetch/XHR\n在官网随意输入一个词后，去右侧点击translate\n复制Cookie值即可", font=("Microsoft YaHei", 10)).pack(pady=35)

# 创建一个输入框
entry = tk.Entry(root,width=64)
entry.pack(pady=0)

# 创建右键菜单
menu = Menu(root, tearoff=0)
menu.add_command(label="剪切", command=cut)
menu.add_command(label="复制", command=copy)
menu.add_command(label="粘贴", command=paste)

# 绑定右键菜单到输入框
def show_menu(event):
    menu.post(event.x_root, event.y_root)
entry.bind("<Button-3>", show_menu)

# 创建设置Cookie按钮
tk.Button(root, text="设置 Cookie", command=set_cookie).pack(pady=35)

# 运行主循环
root.mainloop()






#文件创建和Cookie写入环节
#============================================================================================
#============================================================================================
#============================================================================================
#============================================================================================
#============================================================================================
#做出选择吧！少年(定义函数区)






#定义退出程序函数
def exit_program():
    main.destroy()

#定义总结函数
def AllResults():
    fway=r"C:\ProgramData\EnglishHelper"
    finame='Results.txt'
    fpath=os.path.join(fway,finame)

    with open(fpath, "r", encoding="utf-8") as file:
        content = file.read()
        
    messagebox.showinfo("统计数据", content)

#古希腊掌管启动背单词程序线程的神
def thr():
    #设置文本框内容
    tk.messagebox.showinfo('注意','本程序为模拟人类点击操作\n主程序运行过程中尽可能不要触碰电脑\n否则可能会因为操作冲突导致背单词失败')
    tk.messagebox.showinfo('注意','请在背单词之前打开并登录微信\n登录微信后点击确定\n点击确定后将打开背单词主程序')
                           
    #打开背单词程序
    os.system('FuckEnglish.exe')

#定义调用背单词程序函数
def startanswer():
    start=threading.Thread(target=thr)
    start.start()






#定义函数
#====================================================================
#====================================================================
#====================================================================
#====================================================================
#====================================================================
#程序行为





#创建主窗口
main = tk.Tk()
main.title("去你大爷的英语单词")
main.geometry("320x273+80+60")
main.resizable(width=False, height=False)

#窗口上方文本参数设置
tk.Label(main, text="做出选择的时刻到了", font=("Microsoft YaHei", 10)).pack(pady=21)

#创建查看日志按钮
tk.Button(main, text="查看背单词日志", command=AllResults).pack(pady=10)

#创建背单词按钮
tk.Button(main, text="整", command=startanswer).pack(pady=10)

#创建退出程序按钮
tk.Button(main, text="不整了，退出", command=exit_program).pack(pady=10)

#运行主循环
main.mainloop()





#都跑完了，还不把垃圾清了？
os.remove(delpath)